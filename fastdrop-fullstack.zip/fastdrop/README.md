# FastDrop — منصة توصيل المطاعم والصيدليات والأمانات

منصة سودانية Full-Stack حقيقية: Backend (Node.js + Express + SQLite حقيقية +
مصادقة JWT حقيقية) + Frontend (HTML/CSS/JS يتصل بالـ API الحقيقي، RTL عربي).

---

## 1. البنية

```
fastdrop/
  backend/          # Express API + SQLite database
    db/              # schema.sql, connection, seed script
    middleware/       # auth + role guards
    routes/          # auth, restaurants, pharmacies, orders, favorites, reviews, owner, uploads
    utils/           # auth helpers, settings (delivery fees), audit log helpers
    server.js
    .env.example
  frontend/          # Static site (no build step) — plain HTML/CSS/JS
    index.html
    css/style.css
    js/               # router + all page renderers
```

## 2. التشغيل محليًا

### المتطلبات
- Node.js 18 أو أحدث
- اتصال إنترنت لمرة واحدة لتثبيت الحزم (`npm install`)

### خطوات التشغيل

```bash
cd backend
cp .env.example .env
# افتح .env وغيّر:
#   JWT_SECRET          -> نص عشوائي طويل وسري
#   OWNER_EMAIL/PASSWORD -> بيانات دخول المالك الحقيقية
#   CLIENT_ORIGIN        -> عنوان الفرونت إند (افتراضيًا http://localhost:5173)

npm install
npm run seed     # ينشئ حساب المالك + الحسابات التجريبية + المطاعم/الصيدليات الحقيقية
npm start        # يشغّل السيرفر على http://localhost:4000
```

ثم في نافذة طرفية أخرى، لتشغيل الفرونت إند كملف ثابت (أي سيرفر ثابت يعمل):

```bash
cd frontend
npx http-server -p 5173
# أو: python3 -m http.server 5173
```

افتح المتصفح على `http://localhost:5173`.

> **مهم:** إذا شغّلت الفرونت إند على منفذ (port) مختلف عن 5173، حدّث
> `CLIENT_ORIGIN` في `backend/.env` وأيضًا `window.FASTDROP_API_BASE` في
> `frontend/index.html` ليطابقا بعضهما (الكوكيز الخاصة بالجلسة تعتمد على تطابق
> CORS/Origin بدقة).

### قاعدة البيانات في الإنتاج

هذا المشروع يستخدم **SQLite** للتطوير كما هو مطلوب. للانتقال إلى
**PostgreSQL** في الإنتاج، عدّل `backend/db/index.js` ليستخدم `pg` (أو
Prisma/Knex) بدلًا من `better-sqlite3` مع نفس واجهة `.prepare()/.transaction()`
— ملف `backend/db/schema.sql` مكتوب بصيغة SQL قياسية قابلة للنقل بأقل تعديل
على أنواع الأعمدة (مثل `SERIAL` بدل `INTEGER PRIMARY KEY AUTOINCREMENT`).

---

## 3. الحسابات التجريبية (بعد تشغيل `npm run seed`)

| الدور | البريد الإلكتروني | كلمة المرور | الكود |
|---|---|---|---|
| عميل | customer.demo@fastdrop.test | FastDropDemo123! | — |
| مطعم | restaurant.demo@fastdrop.test | FastDropDemo123! | SFR-RES-000001 |
| صيدلية | pharmacy.demo@fastdrop.test | FastDropDemo123! | SFR-PHA-000001 |
| سائق | driver.demo@fastdrop.test | FastDropDemo123! | SFR-DRV-000001 |
| المالك | القيمة في `OWNER_EMAIL` بملف `.env` | القيمة في `OWNER_PASSWORD` | القيمة في `OWNER_CODE` (افتراضيًا SFR-OWN-2026) |

بالإضافة لذلك، يُنشئ الـ Seed حسابات دخول لكل مطعم من المطاعم الستة الحقيقية
(`restaurant1@fastdrop.test` … `restaurant6@fastdrop.test`، كلمة المرور
`FastDropSeed123!`، بالأكواد `SFR-RES-000002` إلى `SFR-RES-000007` بالترتيب).

**الصيدليات العشر الحقيقية** تُنشأ كسجلات بيانات (اسم، موقع، Plus Code) بدون
حساب دخول مرتبط بها بعد — أنشئ حساب دخول لأي منها من "لوحة تحكم المالك ←
الصيدليات ← إنشاء حساب" وقتما تحتاج ذلك.

---

## 4. ملاحظة مهمة جدًا: الأسعار

تنفيذًا الصارم لقاعدة **"لا تخترع أسعارًا"**، كل أصناف قائمة المطاعم
ومنتجات الصيدليات الحقيقية تُزرع بسعر **NULL** ("السعر غير محدد") ولا يمكن
شراؤها حتى يدخل صاحب المطعم/الصيدلية السعر الحقيقي من لوحة التحكم الخاصة به.

لتجربة تدفق شراء كامل فورًا: سجّل دخول بحساب `restaurant.demo@fastdrop.test`
أو `pharmacy.demo@fastdrop.test`، عدّل سعر أي صنف تجريبي، ثم أكمل الشراء
كعميل. نفس الأمر ينطبق على رسوم التوصيل (تبدأ من 0 ج.س ويحدّدها المالك من
تبويب "الإعدادات").

---

## 5. ما تم اختباره فعليًا في هذه الجلسة

- ✅ فحص بنيوي (`node --check`) لكل ملفات الـ Backend — لا توجد أخطاء صياغية.
- ✅ مراجعة يدوية لمطابقة كل مسار يستدعيه الفرونت إند مع المسار المطابق في
  الـ Backend (auth, restaurants, pharmacies, orders, favorites, reviews,
  owner, uploads).
- ⚠️ **لم يتم تشغيل السيرفر فعليًا داخل بيئة التطوير الحالية** لأن الشبكة
  فيها معطّلة (لا يمكن تنفيذ `npm install` لتنزيل الحزم مثل `express` و
  `better-sqlite3`). بمجرد تنفيذ `npm install` على جهازك سيعمل السيرفر
  مباشرة عبر `npm run seed && npm start`.

**التوصية:** بعد `npm install` نفّذ اختبار سريع يدوي:
1. `npm run seed` — تحقق أنه يطبع رسائل الإنشاء بدون أخطاء.
2. `npm start` — تحقق من ظهور `FastDrop backend running on http://localhost:4000`.
3. افتح `http://localhost:4000/api/health` في المتصفح — يجب أن يعيد `{"ok":true}`.
4. سجّل دخول من الفرونت إند بحساب العميل التجريبي وتصفح مطعمًا.

---

## 6. الميزات المُنفَّذة

- تسجيل دخول/خروج حقيقي بـ JWT + كوكيز HttpOnly + bcrypt، مع أكواد يدوية
  إلزامية للمطاعم/الصيدليات/السائقين/المالك بصيغة `SFR-XXX-000000`.
- Role-based access control فعلي على مستوى الـ Backend (وليس إخفاء واجهات
  فقط) — كل عملية حساسة تتحقق من `req.user.role` وملكية المورد.
- تسعير مُحتسب بالكامل من السيرفر: أي `price`/`total`/`fee` يُرسل من
  الفرونت إند يُتجاهل تمامًا.
- تدفقات حالة الطلب الكاملة (pending → accepted → preparing → ready →
  picked_up → delivering → delivered) لكل من المطاعم والصيدليات والأمانات،
  مع `order_status_history` مسجّل لكل تغيير.
- بحث الأدوية عبر كل الصيدليات دفعة واحدة (قاعدة بيانات حقيقية، وليس فلترة
  في الفرونت إند فقط).
- مراجعة الوصفات الطبية (رفع صورة/PDF، موافقة/رفض من الصيدلية، منع تجاوز
  المراجعة قبل تجهيز الطلب).
- رسوم الإلغاء والرسوم المستحقة (`customer_outstanding_fees`) تُضاف تلقائيًا
  للطلب التالي للعميل.
- لوحة تحكم مالك كاملة: اإحصائيات حقيقية من قاعدة البيانات، إدارة حسابات
  المطاعم/الصيدليات/السائقين (إنشاء، تعديل، تغيير كود، تغيير كلمة مرور،
  تعطيل، تفعيل، حذف ناعم)، سجل تدقيق (`admin_audit_logs`)، إعدادات رسوم
  التوصيل، إشراف على الأمانات والتقييمات والرسوم المستحقة.
- تصميم متجاوب (Mobile-first) بثلاث هويات فرعية: برتقالي فاتح للمطاعم، أزرق
  فاتح للصيدليات، أحمر فاتح للأمانات — كلها تحت هوية FastDrop البرتقالية.

## 7. القيود المعروفة / يحتاج عمل إضافي منك

- **لم يُختبر تشغيليًا** كما هو موضح في القسم 5 — يحتاج `npm install` على
  جهاز متصل بالإنترنت.
- الإشعارات الفورية (`notifications` table) مُنشأة في قاعدة البيانات لكن لا
  يوجد بعد Endpoint أو واجهة لعرضها — تحتاج تطويرًا إضافيًا إذا أردتها.
- لا يوجد نظام دفع إلكتروني فعلي؛ الفواتير تُحسب وتُعرض لكن لا يوجد بوابة
  دفع (Payment Gateway) مدمجة — لم تُذكر في المواصفات الأصلية بوضوح فتُركت
  خارج النطاق.
- رفع الصور يُخزَّن محليًا على القرص (`backend/uploads`) — للإنتاج الحقيقي
  يُفضّل نقلها لخدمة تخزين سحابي (S3 أو مشابه) قبل النشر على سيرفر Production
  فعلي، لأن التخزين المحلي لا يبقى بين عمليات إعادة النشر على أغلب منصات
  الاستضافة.
- ساعات عمل الصيدليات/المطاعم غير مُدرجة كحقل منفصل بعد (المواصفات نصّت أن
  الأوقات "قابلة للتعديل" لكن لم تُحدَّد كحقل قاعدة بيانات) — يمكن إضافتها
  بسهولة إذا حدّدت الصيغة المطلوبة.

---

## 8. أوامر سريعة (مرجع)

```bash
# Backend
cd backend && npm install && npm run seed && npm start

# Frontend (أي سيرفر ثابت)
cd frontend && npx http-server -p 5173
```
